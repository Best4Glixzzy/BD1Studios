#define _

#include <Windows.h>
#include <iostream>
#include <vector>
#include <Psapi.h>

#include <structs.h>
#include <d3d11.h>
#include <D3D11Shader.h>
#include <D3Dcompiler.h>//generateshader

#include <no_imports.h>
#include <MemoryHelper.h>


#pragma comment(lib, "D3dcompiler.lib")
#pragma comment(lib, "d3d11.lib")